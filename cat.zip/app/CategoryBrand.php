<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CategoryBrand extends Model
{
    
}
