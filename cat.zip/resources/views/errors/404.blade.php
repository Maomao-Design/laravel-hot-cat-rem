@extends('layouts.app')

@section('title')
    404 page not
@endsection

@section('content')

    <section style="height: 100px;"></section>

    <section class="text-center section-75 product-class-title">
        404 page not
        <p style="font-size: 12px;padding-top: 10px;">
            <a href="/">返回首页</a>
        </p>
    </section>



@endsection
