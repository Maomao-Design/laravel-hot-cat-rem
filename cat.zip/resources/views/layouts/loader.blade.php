<div class="page-loader page-loader-variant-1">
    <div>
        <a href="index-variant-2.html" class="brand brand-md"><img src="/jcb/imgs/logo.png" width="139" height="22" alt="logo" /></a>
        <div class="page-loader-body">
            <div id="spinningSquaresG">
                <div id="spinningSquaresG_1" class="spinningSquaresG"></div>
                <div id="spinningSquaresG_2" class="spinningSquaresG"></div>
                <div id="spinningSquaresG_3" class="spinningSquaresG"></div>
                <div id="spinningSquaresG_4" class="spinningSquaresG"></div>
                <div id="spinningSquaresG_5" class="spinningSquaresG"></div>
                <div id="spinningSquaresG_6" class="spinningSquaresG"></div>
                <div id="spinningSquaresG_7" class="spinningSquaresG"></div>
                <div id="spinningSquaresG_8" class="spinningSquaresG"></div>
            </div>
        </div>
    </div>
</div>