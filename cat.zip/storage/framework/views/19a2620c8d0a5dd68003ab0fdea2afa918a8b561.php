<?php $__env->startSection('title'); ?>
    Down index
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section style="height: 100px;"></section>

    <section class="text-center section-75 product-class-title">
        Order a catalog
        <p style="font-size: 12px;padding-top: 10px;">
            To find your product take the chance to have a closer look at our catalog.
        </p>
    </section>

    <section class="section-15 section-bottom-60">
        <div class="shell">
            <div class="down-wrap text-center">
                <div class="down-list row range range-md-justify">
                    <div class="down-bg col-md-8">
                        <figure>
                            <img src="/jcb/imgs/down-b.png" alt="" />
                        </figure>
                    </div>
                    <div class="col-md-4 down-btn-wp">
                        <a href="" class="down-btn">
                            View Oline
                        </a>
                    </div>
                </div>
                <div class="down-list row range range-md-justify">
                    <div class="down-bg col-md-8 position-relative">
                        <figure>
                            <img src="/jcb/imgs/down-b.png" alt="" />
                        </figure>
                        <div class="down-pdf">PDF</div>
                    </div>
                    <div class="col-md-4 down-btn-wp">
                        <a href="" class="down-btn">
                            Download
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>