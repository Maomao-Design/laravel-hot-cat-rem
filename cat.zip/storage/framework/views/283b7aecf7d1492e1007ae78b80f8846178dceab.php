<!DOCTYPE html>
<html lang="en" class="wide wow-animation">
<head>
<title><?php echo $__env->yieldContent('title'); ?> <?php echo e(Voyager::setting('title')); ?></title>
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta charset="utf-8">
<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('head'); ?>
</head>
<body style="">
<div class="page">
    <?php echo $__env->make('layouts.loader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<script src="/jcb/js/core.min.js"></script>
<script src="/jcb/js/script.js"></script>
<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>