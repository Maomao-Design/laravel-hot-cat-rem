<?php $__env->startSection('title'); ?>
    <?php echo e($product->title); ?> Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section style="height: 100px;"></section>

    <section class="text-center section-75 product-details-title">
        <h3><?php echo e($category->name); ?></h3>
        <p>
            <?php echo e($product->title); ?>

        </p>
    </section>

    <!--detail-->

    <!--images-->
    <section class="product-bg">
        <div class="shell">
            <img src="/jcb/imgs/pic.png" alt="">
        </div>
    </section>
    <!--images end-->
    <!--body-->
    <section class="product-detail-body section-75">
        <div class="shell">
            <div>
                <?php echo e($product->title); ?>

            </div>
        </div>
    </section>
    <!--body end-->
    <!--detail end-->
    <!--Paging-->

    <section  class="section-15 product-paging">
        <?php echo $__env->make('layouts.paging', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>

    <!--Paging end-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>