<!--blog-->
<script>
    var indexPost = '<?php echo e($posts); ?>';
</script>
<section class="index-blog product-bg section-50">
    <div class="">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-md-pd-0 big-blog-list" >
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->first): ?>
                        <figure class="big-figure">
                            <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>">
                        </figure>
                        <div class="big-blog-bg">

                            <a href="" title="<?php echo e($post->title); ?>">
                                <h5 class="index-blog-model text-center">
                                    News & Events
                                </h5>
                                <h6 class="index-blog-title">
                                    <?php echo e($post->title); ?>

                                </h6>
                                <div class="index-blog-more">
                                    READ MORE
                                </div>
                            </a>
                        </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-6 col-md-6 col-md-pd-0">
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$loop->first): ?>
                            <div class="col-lg-6 col-md-6 col-md-pd-0 big-blog-list" >
                                <figure class="small-figure">
                                    <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>">
                                </figure>
                                <div class="big-blog-bg">
                                    <a href="" title="<?php echo e($post->title); ?>">
                                        <h6 class="index-blog-title">
                                            <?php echo e($post->title); ?>

                                        </h6>
                                        <div class="index-blog-more">
                                            READ MORE
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!--blog end-->