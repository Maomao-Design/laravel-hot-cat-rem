 

<?php $__env->startSection('title', ' '); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('index.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('index.future', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('index.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="section-50 section-sm-60 section-md-75 bg-gray-lighter">
    <div class="shell">
        <div class="range range-sm-center range-sm-middle range-sm-reverse">
            <div class="cell-sm-6 cell-lg-6 text-sm-center">
                <div class="box-container-small text-right">

                    <p class="offset-top-22 text-secondary font-n24">
                        From new oil and gas projects to existing
                        operations, we can help you achieve Top
                        Quartile performance.</p>
                    <a href="" class="btn btn-xl btn-blue-ma offset-top-35 offset-md-top-60">SEE MORE  &nbsp;></a>
                </div>
            </div>
            <div class="cell-sm-6 cell-lg-6 offset-top-40 offset-sm-top-0">
                <div class="image-wrap-1"><img src="/jcb/imgs/thumb-big.png" alt="" width="550" height="480">
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('index.blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>