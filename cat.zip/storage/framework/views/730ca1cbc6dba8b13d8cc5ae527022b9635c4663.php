<?php $__env->startSection('title'); ?>
    Post index
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section style="background-image: url(<?php echo e(asset('jcb/images/bg-image-1.jpg')); ?>);" class="section-165 section-sm-200 section-md-200 section-lg-bottom-265 bg-gray-dark page-title-wrap">
</section>


<!--list-->
<section  class="section-50  section-lg-top-120  product-bg">
    <div class="shell">
        <div class="list-news">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="range range-md-bottom range-sm-center">

                <div class="cell-sm-11 cell-md-6 offset-top-40 offset-sm-top-60 offset-md-top-0">
                    <a href="<?php echo e(URL::route('post',$post->id)); ?>" title="<?php echo e($post->title); ?>">
                        <div class="image-group wow fadeInLeftSmallSmall">
                            <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>" title="<?php echo e($post->title); ?>" >
                        </div>
                    </a>
                </div>
                <div data-wow-duration="2s" data-wow-offset="200" class="cell-sm-10 cell-md-6 wow fadeInRight" >
                    <h6 class="text"><?php echo e($post->title); ?></h6>
                    <p class="offset-top-0">01/03 2017</p>
                    <p class="offset-top-40 text-secondary">
                        <?php echo e($post->excerpt); ?>

                    </p>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="text-center section-50">
            
                
            
        </div>
    </div>
</section>
<!--list end-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>