<div class="shell">
    <div class="range range-md-bottom range-sm-center">
        <div  class="cell-sm-11 cell-md-6" >
            <?php if($prev): ?>
                <a href="<?php echo e(URL::route('post',$prev->id)); ?>">
                    <i class="fa fa-long-arrow-left"></i>
                    <?php echo e($prev->title); ?>

                </a>
            <?php else: ?>
                No more
            <?php endif; ?>
        </div>
        <div class="cell-sm-11 cell-md-6  offset-md-top-0 text-right">
            <?php if($next): ?>
                <a href="<?php echo e(URL::route('post',$next->id)); ?>">
                    <?php echo e($next->title); ?>

                    <i class="fa fa-long-arrow-right"></i>
                </a>
            <?php else: ?>
                No more
            <?php endif; ?>
        </div>
    </div>
</div>