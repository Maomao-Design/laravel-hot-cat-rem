<?php $__env->startSection('title'); ?>
<?php echo e($page->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section style="background-image: url(<?php echo e(asset('/storage/'.$page->image)); ?>)"
         class="section-165 section-sm-200 section-md-200 section-lg-bottom-265 bg-gray-dark page-title-wrap">
</section>


<!--about-->
<section class="section-50  section-lg-top-90 bg-whisper">
    <div class="shell">

        <blockquote class="about-blockquote">
            <p>
                <?php echo $page->excerpt; ?>

            </p>

        </blockquote>

        <div class="about-description">
            <?php echo $page->body; ?>


        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>