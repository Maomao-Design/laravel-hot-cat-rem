<?php $__env->startSection('title'); ?>
    <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!--detail-->
    <section class="product-bg section-md-75 section-sm-15">

        <div class="shell">
            <div class="new-detail-max-width section-xl-top-50 section-sm-top-15">
                <div class="new-detail-title text-center main-title-color">
                    <?php echo e($post->title); ?>

                </div>
                <div class="new-detail-time text-center main-title-color">
                    <?php echo e($post->created_at->format('m/d Y')); ?>

                </div>

                <div class="new-detail-pic">
                    <figure>
                        <img src=" <?php echo e(asset('storage/'.$post->image )); ?>" alt="" >
                    </figure>
                </div>

                <div class="new-detail-body">
                    <p>
                        <?php echo $post->body; ?>

                    </p>
                </div>
            </div>
        </div>
        <div class="section-15"></div>
        <section  class="section-15 news-paging">
            <?php echo $__env->make('layouts.paging', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--Paging end-->
        </section>
    </section>
    <!--detail end-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>