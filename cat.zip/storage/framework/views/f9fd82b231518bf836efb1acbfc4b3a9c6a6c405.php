<?php $__env->startSection('title'); ?>
    404 page not
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section style="height: 100px;"></section>

    <section class="text-center section-75 product-class-title">
        404 page not
        <p style="font-size: 12px;padding-top: 10px;">
            <a href="/">返回首页</a>
        </p>
    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>